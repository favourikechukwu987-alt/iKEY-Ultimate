plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ikey.ultimate"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ikey.ultimate"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
